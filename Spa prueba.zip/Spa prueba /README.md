
# SPA Online Event Management
This is a Single Page Application (SPA) for a page that organizes and manages events. 
Allows you to manage events, register users, and protect routes based on role. 
The application uses **JavaScript, HTML5, CSS** and simulates a database with json-server

## Main features

**Authentication**
- Registration and login for **administrators** and **users**
- Role-protected routes
- Session persistence with **localStorage**

- **Administration**
- Create, edit, and delete events
- View registered users by event

- **Students**
- View available events
- Register for events if available
- View events they are registered for

- **Dynamic SPA**
- Hashed routing ('#/login', '#/register', '#/dashboard')
- Automatic redirection if not logged in or without permissions
- Smooth, reload-free navigation

