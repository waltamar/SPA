import { apiRequest } from './api.js';


export async function registerUser(userData) {
    // Verifica si el username ya existe
    const users = await apiRequest('users', 'GET');
    const userExists = users.find(u => u.username === userData.username);
    if (userExists) {
        alert('El nombre de usuario ya existe.');
        return;
    }
    await apiRequest('users', 'POST', userData);
    alert('Usuario registrado. Ahora puedes iniciar sesión.');
    window.location.hash = '#/login';
}
//inisiar sesion
export async function loginUser(username, password) {
  const users = await apiRequest('users', 'GET');
  const user = users.find(u => u.username === username && u.password === password);

  if (!user) {
    alert('Credenciales inválidas.');
    return;
  }

  // Guarda sesión
  localStorage.setItem('user', JSON.stringify(user));
  window.location.hash = '#/dashboard';
}


//Cerrar sesión
export function logoutUser() {
  localStorage.removeItem('user');
  window.location.hash = '#/login';

}

//Obtener usuario actual desde localStorage 
export function getCurrentUser() {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}


//Verifica si ruta requiere autenticación y rol
 export function protectRoute(allowedRoles = []) {
  const user = getCurrentUser();
  if (!user) {
    window.location.hash = '#/not-found';
    return false;
  }
  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    window.location.hash = '#/not-found';
    return false;
  }
  return true;
}