
//Redirigir a una ruta específica (usa hash)

export function redirect(path) {
  window.location.hash = `#${path}`;
}

//Limpiar contenido de un contenedor por ID

export function clearContainer(id) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = '';
}

/**
 * Mostrar un mensaje dentro de un contenedor
 * @param {string} id - ID del contenedor
 * @param {string} message - Texto a mostrar
 * @param {string} type - success | error | info
 */
export function showMessage(id, message, type = 'info') {
  const el = document.getElementById(id);
  if (!el) return;

  el.innerHTML = `<div class="msg ${type}">${message}</div>`;
}

/**
 * Validar campos vacíos de un formulario
 * @param {Array} fields - Lista de IDs de input
 * @returns {boolean} true si todos están llenos
 */
export function validateFields(fields) {
  for (let id of fields) {
    const value = document.getElementById(id)?.value.trim();
    if (!value) return false;
  }
  return true;
}
