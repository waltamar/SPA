import { apiRequest } from './api.js';
import { getCurrentUser } from './auth.js';
import { renderEventsAdminView } from './views.js';

// Cargar lista de eventos (para panel admin)
export async function listCourses() {
  const courses = await apiRequest('events', 'GET');
  renderEventsAdminView(courses);
}



// Crear evento nuevo
export async function createEvent(eventData) {
  const user = getCurrentUser();
  if (!user || user.role !== 'admin') {
    alert('No tienes permisos.');
    return;
  }

  await apiRequest('events', 'POST', eventData);
  listEvent(); 
}


// Editar evento existente
export async function updateEvent(eventId, updatedData) {
  const user = getCurrentUser();
  if (!user || user.role !== 'admin') {
    alert('No tienes permisos.');
    return;
  }

  await apiRequest(`events/${eventId}`, 'PUT', updatedData);
  listEvent();
}


// Eliminar evento 
export async function deleteEvent(eventId) {
  const user = getCurrentUser();
  if (!user || user.role !== 'admin') {
    alert('No tienes permisos.');
    return;
  }

  const confirmDelete = confirm('¿Estás seguro de eliminar este evento?');
  if (!confirmDelete) return;

  await apiRequest(`events/${eventId}`, 'DELETE');
  listEvent();
}

// Ver usuarios inscrito
export async function listEnrolledUsers(eventId) {
  const enrollments = await apiRequest('enrollments', 'GET');
  const users = enrollments.filter(e => e.eventId === eventId);
  console.log(`Usuarios inscritos en el evento ${eventId}:`, users);

}