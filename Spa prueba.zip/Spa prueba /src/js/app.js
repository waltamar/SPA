import { router } from './routes.js';
import { getCurrentUser } from './auth.js';

//navegación según sesión
function renderNavbar() {
  const navbar = document.getElementById('navbar');
  const user = getCurrentUser();

  if (!navbar) return;

  if (user) {
    navbar.innerHTML = `
      <a href="#/dashboard">Dashboard</a>
      <a href="#/logout">Cerrar sesión</a>
    `;
  } else {
    navbar.innerHTML = `
      <a href="#/login">Iniciar sesión</a>
      <a href="#/register">Registrarse</a>
    `;
  }
}

// Evento inicial
window.addEventListener('load', () => {
  renderNavbar();
  router();
});

// Evento hashchange (cuando cambias de vista)
window.addEventListener('hashchange', () => {
  renderNavbar();
  router();
});
