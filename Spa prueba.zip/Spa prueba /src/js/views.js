// src/js/views.js

/**
 * Renderiza la lista de eventos en el panel de administrador.
 * @param {Array} events
 */
export function renderEventdminView(events) {
  const container = document.getElementById('eventsList');
  if (!container) {
    console.warn('No se encontró el contenedor #eventsList');
    return;
  }

  container.innerHTML = '<h2>Lista de eventos</h2>';

  events.forEach(event => {
    const div = document.createElement('div');
    div.classList.add('course-card');
    div.innerHTML = `
      <h3>${event.title}</h3>
      <p><strong>Descripción:</strong> ${event.description}</p>
      <p><strong>Cantante:</strong> ${event.singer}</p>
      <p><strong>Categoría:</strong> ${event.category}</p>
      <p><strong>Cupo:</strong> ${event.capacity}</p>
      <button data-id="${event.id}" class="edit-event">Editar</button>
      <button data-id="${event.id}" class="delete-event">Eliminar</button>
    `;
    container.appendChild(div);
  });
}


/**
 * Renderiza la lista de eventos para un usuario.
 * @param {Array} events
 */
export function renderEventsUserView(events) {
  const container = document.getElementById('eventsList');
  if (!container) {
    console.warn('No se encontró el contenedor #eventsList');
    return;
  }

  container.innerHTML = '<h2>Cursos disponibles</h2>';

  events.forEach(event => {
    const div = document.createElement('div');
    div.classList.add('event-card');
    div.innerHTML = `
      <h3>${event.title}</h3>
      <p>${event.description}</p>
      <p><strong>Cantante:</strong> ${event.singer}</p>
      <p><strong>Categoría:</strong> ${event.category}</p>
      <p><strong>Cupo disponible:</strong> ${event.capacity}</p>
      <button data-id="${event.id}" class="enroll-event">Inscribirse</button>
    `;
    container.appendChild(div);
  });
}


/**
 * Renderiza la lista de eventos en los que está inscrito un usuario.
 * @param {Array} enrollments
 */
export function renderUserEnrollments(enrollments) {
  const container = document.getElementById('myEvent');
  if (!container) {
    console.warn('No se encontró el contenedor #myEvent');
    return;
  }

  container.innerHTML = '<h2>Mis Eventos</h2>';

  enrollments.forEach(enrollment => {
    const div = document.createElement('div');
    div.classList.add('enrollment-card');
    div.innerHTML = `
      <h3>${enrollment.title}</h3>
      <p>${enrollment.description}</p>
    `;
    container.appendChild(div);
  });
}
