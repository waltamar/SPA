import { protectRoute, logoutUser, getCurrentUser } from './auth.js';
import { listEvent, createEvent} from './admin.js';
import { listAvailableEvent, enrollInCourse } from './users.js';
import { registerUser, loginUser } from './auth.js';

export function router() {
  const app = document.getElementById('app');
  const route = window.location.hash.slice(1) || '/login';
  const user = getCurrentUser();

  switch (route) {

    // VISTA LOGIN
    case '/login':
      if (user) {
        window.location.hash = '#/dashboard';
        return;
      }
      app.innerHTML = `
        <h2>Iniciar Sesión</h2>
        <form id="loginForm">
          <input type="text" id="username" placeholder="Usuario" required />
          <input type="password" id="password" placeholder="Contraseña" required />
          <button type="submit">Entrar</button>
        </form>
      `;
      document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        await loginUser(username, password);
      });
      break;

    // VISTA REGISTRO
    case '/register':
      if (user) {
        window.location.hash = '#/dashboard';
        return;
      }
      app.innerHTML = `
        <h2>Registro</h2>
        <form id="registerForm">
          <input type="text" id="username" placeholder="Usuario" required />
          <input type="password" id="password" placeholder="Contraseña" required />
          <select id="role">
            <option value="nomarl-user">Usuario</option>
          </select>
          <button type="submit">Registrar</button>
        </form>
      `;
      document.getElementById('registerForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const userData = {
          username: document.getElementById('username').value,
          password: document.getElementById('password').value,
          role: document.getElementById('role').value
        };
        await registerUser(userData);
      });
      break;

    // DASHBOARD GENERAL
    case '/dashboard':
      if (!protectRoute()) return;
      if (user.role === 'admin') {
        app.innerHTML = `
          <h2>Panel de Administración</h2>
          <button id="createEventBtn">Crear evento</button>
          <div id="eventAdmin"></div>
        `;
        document.getElementById('createEventBtn').addEventListener('click', renderCreateEventForm);
        listEvent();
      } else if (user.role === 'users') {
        app.innerHTML = `
          <h2>Eventos Disponibles</h2>
          <div id="eventUser"></div>
        `;
        listAvailableEvent();
      }
      break;

    // CERRAR SESIÓN
    case '/logout':
      logoutUser();
      break;

    // RUTA NO ENCONTRADA
    default:
      app.innerHTML = `
        <h2>404 - Página no encontrada</h2>
        <p>La ruta <code>${route}</code> no existe o no tienes permisos.</p>
      `;
      break;
  }
}

// Renderizar formulario para crear curso (sólo admin)
function renderCreateEventForm() {
  const app = document.getElementById('app');
  app.innerHTML += `
    <h3>Nuevo evento</h3>
    <form id="createEventForm">
      <input type="text" id="title" placeholder="Título" required />
      <textarea id="description" placeholder="Descripción" required></textarea>
      <input type="text" id="category" placeholder="Categoría" required />
      <input type="number" id="capacity" placeholder="Capacidad máxima" required />
      <input type="text" id="singer" placeholder="cantante" required />
      <button type="submit">Guardar evento </button>
    </form>
  `;

  document.getElementById('createEventForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const eventData = {
      title: document.getElementById('title').value,
      description: document.getElementById('description').value,
      category: document.getElementById('category').value,
      capacity: parseInt(document.getElementById('capacity').value),
      singer: document.getElementById('singer').value
    };
    await createEvent(eventData);
  });
}
