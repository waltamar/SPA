const baseUrl = '/http://localhost:3000';

export async function apiRequest(endpoint, method = 'GET', bodyData = null) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json'
    }
  };

  if (bodyData) {
    options.body = JSON.stringify(bodyData);
  }

  try {
    const response = await fetch(`${baseUrl}/${endpoint}`, options);

    if (!response.ok) {
      throw new Error(`Error ${response.status}: ${response.statusText}`);
    }

    // Si es DELETE, no hay body que devolver
    if (method === 'DELETE') {
      return true;
    }

    const data = await response.json();
    return data;

  } catch (error) {
    console.error('API error:', error.message);
    alert('Error en la comunicación con el servidor.');
    return null;
  }
}
