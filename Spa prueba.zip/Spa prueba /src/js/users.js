import { apiRequest } from './api.js';
import { getCurrentUser } from './auth.js';

// Mostrar cursos disponibles para usuarios
export async function listAvailableEvent() {
  const user = getCurrentUser();
  if (!user || user.role !== 'user') {
    alert('No tienes permisos.');
    return;
  }

  const event = await apiRequest('event', 'GET');
  const enrollments = await apiRequest('enrollments', 'GET');

  const app = document.getElementById('eventUser');
  app.innerHTML = '';

  event.forEach(event => {
    const enrolledCount = enrollments.filter(e => e.eventId === event.id).length;
    const available = enrolledCount < event.capacity;

    app.innerHTML += `
      <div class="event-card">
        <h3>${event.title}</h3>
        <p>${event.description}</p>
        <p>Categoría: ${event.category}</p>
        <p>Instructor: ${event.singer}</p>
        <p>Cupos: ${enrolledCount}/${event.capacity}</p>
        ${available ? `<button data-id="${event.id}" class="enroll-btn">Inscribirse</button>` : `<span>Evento lleno</span>`}
      </div>
    `;
  });

  // Delegar evento a todos los botones de inscripción
  document.querySelectorAll('.enroll-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const eventId = parseInt(e.target.dataset.id);
      await enrollInEvent(eventId);
    });
  });
}

// Inscribir estudiante en curso
export async function enrollInEvent(eventId) {
  const user = getCurrentUser();
  if (!user || user.role !== 'user') {
    alert('No tienes permisos.');
    return;
  }

  const enrollments = await apiRequest('enrollments', 'GET');
  const alreadyEnrolled = enrollments.find(e => e.eventId === eventId && e.userId === user.id);

  if (alreadyEnrolled) {
    alert('Ya estás inscrito en este evento.');
    return;
  }

  await apiRequest('enrollments', 'POST', {
    eventId,
    eventId: user.id
  });

  alert('Inscripción exitosa.');
  listAvailableEvent();
}

// Mostrar cursos en los que está inscrito
export async function listMyEvent() {
  const user = getCurrentUser();
  if (!user || user.role !== 'user') {
    alert('No tienes permisos.');
    return;
  }

  const enrollments = await apiRequest('enrollments', 'GET');
  const myEnrollments = enrollments.filter(e => e.usertId === user.id);

  const event = await apiRequest('event', 'GET');
  const myEvent = event.filter(c => myEnrollments.some(e => e.eventId === c.id));

  const app = document.getElementById('app');
  app.innerHTML = '<h2>Mis eventos</h2>';

  myEvent.forEach(event => {
    app.innerHTML += `
      <div class="event-card">
        <h3>${event.title}</h3>
        <p>${event.description}</p>
      </div>
    `;
  });
}
